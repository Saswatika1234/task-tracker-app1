import React, { useState } from 'react';
import axios from 'axios';

export default function Login() {
    const [form, setForm] = useState({ username: '', password: '' });

    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async e => {
        e.preventDefault();
        const res = await axios.post('http://localhost:5000/api/auth/login', form);
        localStorage.setItem('token', res.data.token);
        alert('Login successful!');
    };

    return (
        <form onSubmit={handleSubmit}>
            <input name="username" onChange={handleChange} placeholder="Username" />
            <input name="password" onChange={handleChange} placeholder="Password" type="password" />
            <button type="submit">Log In</button>
        </form>
    );
}
