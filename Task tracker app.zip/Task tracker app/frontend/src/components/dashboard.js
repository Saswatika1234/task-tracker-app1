import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Dashboard() {
    const [projects, setProjects] = useState([]);
    const token = localStorage.getItem('token');

    useEffect(() => {
        axios.get('http://localhost:5000/api/projects', {
            headers: { Authorization: token }
        }).then(res => setProjects(res.data));
    }, [token]);

    return (
        <div>
            <h1>Projects</h1>
            <ul>
                {projects.map(p => <li key={p._id}>{p.name}</li>)}
            </ul>
        </div>
    );
}
