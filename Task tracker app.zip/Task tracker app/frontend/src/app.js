import React from 'react';
import Signup from './components/signup';
import Login from './components/login';
import Dashboard from './components/dashboard';

export default function App() {
    return (
        <div>
            <Signup />
            <Login />
            <Dashboard />
        </div>
    );
}
