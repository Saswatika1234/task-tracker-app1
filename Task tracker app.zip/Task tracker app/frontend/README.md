# Task Tracker App

A full-stack app to manage projects and tasks with user authentication.

## Technologies
- Backend: Node.js, Express.js, MongoDB, JWT
- Frontend: React.js, Axios

## Run Backend
```bash
cd backend
npm install
npm start
