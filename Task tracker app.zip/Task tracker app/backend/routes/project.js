const express = require('express');
const jwt = require('jsonwebtoken');
const Project = require('../models/project');

const router = express.Router();

router.use((req, res, next) => {
    const token = req.headers.authorization;
    if (!token) return res.status(401).json({ error: 'No token provided' });
    try {
        const decoded = jwt.verify(token, 'secret_key');
        req.userId = decoded.id;
        next();
    } catch {
        res.status(403).json({ error: 'Invalid token' });
    }
});

router.get('/', async (req, res) => {
    const projects = await Project.find({ userId: req.userId });
    res.json(projects);
});

router.post('/', async (req, res) => {
    const project = await Project.create({ name: req.body.name, userId: req.userId });
    res.status(201).json(project);
});

module.exports = router;
