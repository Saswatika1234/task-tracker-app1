const express = require('express');
const jwt = require('jsonwebtoken');
const Task = require('../models/task');

const router = express.Router();

router.use((req, res, next) => {
    const token = req.headers.authorization;
    if (!token) return res.status(401).json({ error: 'No token provided' });
    try {
        const decoded = jwt.verify(token, 'secret_key');
        req.userId = decoded.id;
        next();
    } catch {
        res.status(403).json({ error: 'Invalid token' });
    }
});

router.get('/:projectId', async (req, res) => {
    const tasks = await Task.find({ projectId: req.params.projectId });
    res.json(tasks);
});

router.post('/:projectId', async (req, res) => {
    const task = await Task.create({ name: req.body.name, projectId: req.params.projectId });
    res.status(201).json(task);
});

router.delete('/:taskId', async (req, res) => {
    await Task.findByIdAndDelete(req.params.taskId);
    res.json({ message: 'Task deleted' });
});

module.exports = router;
