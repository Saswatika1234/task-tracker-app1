const mongoose = require('mongoose');
const TaskSchema = new mongoose.Schema({
    name: String,
    projectId: mongoose.Schema.Types.ObjectId
});
module.exports = mongoose.model('Task', TaskSchema);
